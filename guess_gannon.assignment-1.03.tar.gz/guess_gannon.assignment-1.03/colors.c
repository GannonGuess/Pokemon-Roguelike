//File for colorizing output
void blue() {
    printf("\e[1;34m");
}

void black() {
    printf("\e[1;30m");
}

void cyan() {
    printf("\e[0;36m");
}

void yellow() {
    printf("\e[0;33m");
}

void green() {
    printf("\e[0;32m");
}

void white() {
    printf("\x1b[m");
}

void red() {
    printf("\e[0;31m");
}

void purple() {
    printf("\e[0;35m");
}
