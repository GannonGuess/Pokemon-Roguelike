8/28 19:42 - Created README, Makefile, terrain.c, and CHANGELOG

8/29 12:07 - Adding grid initilization and terrain generation without structs (short grass and borders)

8/29 12:30 - Added basic random terrain generation for water and tall grass

8/29 13:15 - Added enterance and exits in cardinal directions for paths to connect

9/10 13:17 - Added structs for defining rooms. Redefined initial border and short grass generation to use the struct

9/10 14:23 - Added variable terrain generation with structs (water and tall grass)

9/10 15:32 - Added path generation, choosing random turn points

9/10 19:33 - Added Center and Mart generation that connects them to the nearest path with a 2-wide path

9/10 20:39 - Altered terrain generation to make bigger patches of terrain more often

9/10 21:09 - Added tree generation for more variety

9/10 21:15 - Added boulder generation for variety

9/10 21:30 - Packaging for submission